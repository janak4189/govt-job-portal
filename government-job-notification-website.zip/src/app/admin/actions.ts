"use server";

import { db } from "@/db";
import { jobs } from "@/db/schema";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export async function postJob(formData: FormData) {
  const title = formData.get("title") as string;
  const department = formData.get("department") as string;
  const location = formData.get("location") as string;
  const description = formData.get("description") as string;
  const qualification = formData.get("qualification") as string;
  const salary = formData.get("salary") as string;
  const lastDate = formData.get("lastDate") as string;
  const applicationUrl = formData.get("applicationUrl") as string;

  if (!title || !department || !location || !description || !lastDate || !applicationUrl) {
    throw new Error("Missing required fields");
  }

  const [newJob] = await db.insert(jobs).values({
    title,
    department,
    location,
    description,
    qualification,
    salary,
    lastDate: new Date(lastDate),
    applicationUrl,
  }).returning();

  revalidatePath("/");
  revalidatePath("/jobs");
  redirect(`/jobs/${newJob.id}`);
}
