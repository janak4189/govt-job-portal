import { db } from "@/db";
import { jobs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { format } from "date-fns";
import { Building, MapPin, Calendar, Clock, GraduationCap, IndianRupee, ExternalLink, ArrowLeft } from "lucide-react";
import Link from "next/link";

export default async function JobDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const jobId = parseInt(id, 10);
  
  if (isNaN(jobId)) {
    notFound();
  }

  const job = await db.select().from(jobs).where(eq(jobs.id, jobId)).limit(1);

  if (job.length === 0) {
    notFound();
  }

  const data = job[0];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Link href="/" className="inline-flex items-center text-sm font-medium text-gray-500 hover:text-indigo-600 mb-2">
        <ArrowLeft className="w-4 h-4 mr-1" /> Back to Jobs
      </Link>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
        {/* Header */}
        <div className="bg-indigo-50/50 p-6 md:p-8 border-b border-gray-200">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold text-gray-900 mb-4">{data.title}</h1>
              <div className="flex flex-wrap items-center gap-4 text-gray-600 font-medium">
                <span className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-md border shadow-sm">
                  <Building className="w-4 h-4 text-indigo-500" />
                  {data.department}
                </span>
                <span className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-md border shadow-sm">
                  <MapPin className="w-4 h-4 text-indigo-500" />
                  {data.location}
                </span>
              </div>
            </div>
            <div className="shrink-0 text-left md:text-right">
              <div className="inline-flex flex-col bg-white border border-red-100 rounded-lg p-3 shadow-sm min-w-[150px]">
                <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Last Date to Apply</span>
                <span className="text-lg font-bold text-red-600 flex items-center gap-1.5">
                  <Calendar className="w-5 h-5" />
                  {format(new Date(data.lastDate), 'dd MMM yyyy')}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 md:p-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            <div className="md:col-span-2 space-y-8">
              <section>
                <h2 className="text-xl font-bold text-gray-900 mb-4 pb-2 border-b">Job Description</h2>
                <div className="prose prose-indigo max-w-none text-gray-700 whitespace-pre-wrap">
                  {data.description}
                </div>
              </section>

              <section>
                <h2 className="text-xl font-bold text-gray-900 mb-4 pb-2 border-b">Important Dates</h2>
                <ul className="space-y-3">
                  <li className="flex items-center gap-3 text-gray-700">
                    <Clock className="w-5 h-5 text-indigo-500" />
                    <span><strong>Posted On:</strong> {format(new Date(data.postedDate), 'MMMM dd, yyyy')}</span>
                  </li>
                  <li className="flex items-center gap-3 text-gray-700">
                    <Calendar className="w-5 h-5 text-red-500" />
                    <span><strong>Closing Date:</strong> {format(new Date(data.lastDate), 'MMMM dd, yyyy')}</span>
                  </li>
                </ul>
              </section>
            </div>

            <div className="space-y-6">
              <div className="bg-gray-50 rounded-xl p-5 border border-gray-100">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Quick Facts</h3>
                
                <div className="space-y-4">
                  {data.qualification && (
                    <div>
                      <span className="text-xs font-semibold text-gray-500 uppercase block mb-1">Qualification</span>
                      <div className="flex items-start gap-2 text-gray-800 font-medium">
                        <GraduationCap className="w-5 h-5 text-indigo-500 shrink-0 mt-0.5" />
                        <span>{data.qualification}</span>
                      </div>
                    </div>
                  )}

                  {data.salary && (
                    <div>
                      <span className="text-xs font-semibold text-gray-500 uppercase block mb-1">Salary / Pay Scale</span>
                      <div className="flex items-start gap-2 text-gray-800 font-medium">
                        <IndianRupee className="w-5 h-5 text-indigo-500 shrink-0 mt-0.5" />
                        <span>{data.salary}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <a 
                href={data.applicationUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-lg shadow-md transition-colors"
              >
                Apply Now <ExternalLink className="w-5 h-5" />
              </a>
              <p className="text-xs text-center text-gray-500">
                Clicking apply will take you to the official recruitment website.
              </p>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}
