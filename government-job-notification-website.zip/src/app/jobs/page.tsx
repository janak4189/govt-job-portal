import { db } from "@/db";
import { jobs } from "@/db/schema";
import { desc } from "drizzle-orm";
import Link from "next/link";
import { format } from "date-fns";
import { MapPin, Building, Calendar } from "lucide-react";

export default async function JobsPage() {
  const allJobs = await db.select()
    .from(jobs)
    .orderBy(desc(jobs.postedDate));

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">All Government Jobs</h1>
        <p className="text-gray-600">Browse all available government job notifications and apply before the deadline.</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="divide-y divide-gray-200">
          {allJobs.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              No jobs available at the moment.
            </div>
          ) : (
            allJobs.map((job) => (
              <div key={job.id} className="p-6 hover:bg-gray-50 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex-1">
                  <Link href={`/jobs/${job.id}`}>
                    <h2 className="text-xl font-bold text-indigo-700 hover:underline mb-2">{job.title}</h2>
                  </Link>
                  <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-1">
                      <Building className="w-4 h-4" />
                      <span>{job.department}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      <span>{job.location}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col gap-2 md:items-end md:min-w-[200px]">
                  <div className="flex items-center gap-1 text-sm bg-red-50 text-red-700 px-3 py-1 rounded-full w-fit">
                    <Calendar className="w-4 h-4" />
                    <span className="font-medium">Ends: {format(new Date(job.lastDate), 'dd MMM yyyy')}</span>
                  </div>
                  <Link 
                    href={`/jobs/${job.id}`}
                    className="mt-2 md:mt-0 text-sm font-medium text-indigo-600 border border-indigo-600 px-4 py-2 rounded hover:bg-indigo-50 transition-colors w-fit md:w-auto text-center"
                  >
                    View Details
                  </Link>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
